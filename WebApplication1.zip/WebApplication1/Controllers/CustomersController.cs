﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly IHttpContextAccessor _contextAccessor;

        public CustomersController(IHttpContextAccessor contextAccessor)
        {
            _contextAccessor = contextAccessor;
        }
        [HttpGet, Authorize]
        public IEnumerable<string> Get()
        {
            var UserID = _contextAccessor.HttpContext.User?.FindFirstValue(ClaimTypes.NameIdentifier);
            var Role = _contextAccessor.HttpContext.User?.FindFirstValue(ClaimTypes.Role.ToString());
            return new string[] { "John Doe", "Jane Doe" };
        }

    }
}
