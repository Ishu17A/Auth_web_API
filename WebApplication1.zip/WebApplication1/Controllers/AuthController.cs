﻿using AutoMapper;
using MailKit;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WebApplication1.Models;
using static System.Net.WebRequestMethods;

namespace WebApplication1.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IMapper _mapper;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly IMailServices _mailService;

        public AuthController(SignInManager<IdentityUser> signInManager, UserManager<IdentityUser> userManager, IMapper mapper, IHttpContextAccessor contextAccessor, IMailServices mailService)
        {
            _signInManager = signInManager;
            _userManager = userManager;
            _mapper = mapper;
            _contextAccessor = contextAccessor;
            _mailService = mailService;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> LoginAsync(Login users)
        {
            var user = await _userManager.FindByNameAsync(users.UserName);
            if (user != null &&
                await _userManager.CheckPasswordAsync(user, users.Password))
            {
                var userRole = await _userManager.GetRolesAsync(user);
                var role = userRole.FirstOrDefault().ToString();
                await _signInManager.PasswordSignInAsync(user, users.Password, true, false);
                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345"));
                var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
                var tokeOptions = new JwtSecurityToken(
                    issuer: "https://localhost:7063",
                    audience: "https://localhost:7063",
                    claims: new List<Claim> { new Claim(ClaimTypes.NameIdentifier, user.Id), new Claim(ClaimTypes.Name, user.UserName), new Claim(ClaimTypes.Role, role) },
                    expires: DateTime.Now.AddMinutes(5),
                    signingCredentials: signinCredentials
                );
                string tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                return Ok(tokenString);
            }
            return BadRequest();
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout(AuthenticatedResponse response)
        {
            if (response != null)
            {
                await _signInManager.SignOutAsync();
                response.Token = null;
            }
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("RegisterUser")]
        public async Task<IActionResult> Register(RegisterUser users)
        {
            if (users != null)
            {
                var user = _mapper.Map<IdentityUser>(users);
                var result = await _userManager.CreateAsync(user, users.Password);
                if (!result.Succeeded)
                {
                    foreach (var error in result.Errors)
                    {
                        ModelState.TryAddModelError(error.Code, error.Description);
                    }
                    return BadRequest(ModelState);
                }
                await _userManager.AddToRoleAsync(user, "User");
                return Ok("Registered");
            }
            return BadRequest();
        }

        [HttpPost("changeRole")]
        public async Task<IActionResult> Changerole(string email)
        {
            if (email != null)
            {
                var userName = await _userManager.FindByEmailAsync(email);
                var userRoles = await _userManager.GetRolesAsync(userName);
                if (userRoles != null)
                {
                    await _userManager.RemoveFromRoleAsync(userName, "User");
                    await _userManager.AddToRoleAsync(userName, "Manager");
                }
                var userRole = await _userManager.GetRolesAsync(userName);
                return Ok("Role changed");
            }
            return BadRequest();
        }

        [HttpPost("ChangePassword")]
        public async Task<IActionResult> ChangePassword(PasswordChange passwordChange)
        {
            var UserID = _contextAccessor.HttpContext.User?.FindFirstValue(ClaimTypes.NameIdentifier);
            if (ModelState.IsValid)
            {
                var userData = await _userManager.FindByIdAsync(UserID);
                await _userManager.ChangePasswordAsync(userData, passwordChange.OldPassword, passwordChange.NewPassword);
                return Ok();
            }
            return BadRequest();
        }

        [AllowAnonymous]
        [HttpPost("ForgetPassword")]
        public async Task<IActionResult> ForgetPassword(string email)
        {
            var user = await _userManager.FindByEmailAsync(email);
            if (user != null)
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                var request = new MailRequest();
                request.Body = "<a href='https://localhost:7063/swagger/index.html'>Click Here</a>";
                request.ToEmail = email;
                request.Subject = "Test Email";
                await _mailService.SendEmailAsync(request);
                return Ok("UserId: " + user.Id + "\n" + "Token: " + token);              
            }
            return BadRequest();
        }


        [AllowAnonymous]
        [HttpPost("ResetPassword")]
        public async Task<IActionResult>ResetPassword(ResetPassword request)
        {
            if (ModelState.IsValid)
            {
            var user = await _userManager.FindByIdAsync(request.UserId);
            await _userManager.ResetPasswordAsync(user, request.Token,request.NewPassword);
                return Ok();
            }
            return BadRequest();    
        }





    }
}
