﻿namespace WebApplication1.Models
{
    public class AuthenticatedResponse
    {
       public string? Token { get; set; }
    }
}
