﻿namespace WebApplication1.Models
{
    public class ResetPassword
    {
        public string Token { get; set; }
        public string UserId { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmPassword { get; set;}
    }
}
