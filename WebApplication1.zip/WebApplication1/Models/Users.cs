﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    //public class Users : RegisterUser
    //{
    //    [Key]
    //    public Guid Id { get; set; } = Guid.NewGuid();
    //}
}
