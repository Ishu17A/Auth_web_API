﻿namespace WebApplication1.Models
{
    public interface IMailServices
    {
        Task SendEmailAsync(MailRequest mailRequest);

        //Task SendEmailAsync (string email); 

    }
}
