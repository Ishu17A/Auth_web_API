﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;


namespace WebApplication1.Models
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<RegisterUser, IdentityUser>()
                .ForMember(u => u.UserName, opt => opt.MapFrom(x => x.FirstName));
        }
    }
}
