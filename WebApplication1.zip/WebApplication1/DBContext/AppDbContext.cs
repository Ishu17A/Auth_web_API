﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.DBContext
{
    public class AppDbContext : IdentityDbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            this.SeedUsers(builder);
            this.SeedRoles(builder);    
            this.SeedUserRoles(builder);
        }

        private void SeedUsers(ModelBuilder builder)
        {
            IdentityUser user = new IdentityUser()
            {
                Id = "b74ddd14-6340-4840-95c2-db12554843e5",
                UserName = "Admin",
                Email = "admin@gmail.com",            
                PhoneNumber = "1234567890",
                NormalizedUserName = "ADMIN"
            };
            IdentityUser user2 = new IdentityUser
            {
                Id = "b74ddd14-6340-4840-95c2-db12554843e6",
                UserName = "User",
                Email = "user@gmail.com",           
                PhoneNumber = "1234567800",
                NormalizedUserName = "USER"
            };

            PasswordHasher<IdentityUser> passwordHasher = new PasswordHasher<IdentityUser>();
            user.PasswordHash = passwordHasher.HashPassword(user, "Admin@123");
            user2.PasswordHash = passwordHasher.HashPassword(user2, "User@123");

            builder.Entity<IdentityUser>().HasData(user);
            builder.Entity<IdentityUser>().HasData(user2);
        }
        private void SeedRoles(ModelBuilder builder)
        {
            builder.Entity<IdentityRole>().HasData(
                new IdentityRole() { Id = "fab4fac1-c546-41de-aebc-a14da6895711", Name = "Admin", ConcurrencyStamp = "1", NormalizedName = "Admin" },
                new IdentityRole() {  Id = "fab4fac1-c546-41de-aebc-a14da6895712", Name = "User" , ConcurrencyStamp = "2" , NormalizedName = "User" },
                new IdentityRole() {  Id = "fab4fac1-c546-41de-aebc-a14da6895713", Name = "Manager" , ConcurrencyStamp = "3" , NormalizedName = "Manager" }    
                
                );
        }
        private void SeedUserRoles(ModelBuilder builder)
        {
            builder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string>() { RoleId = "fab4fac1-c546-41de-aebc-a14da6895711", UserId = "b74ddd14-6340-4840-95c2-db12554843e5" },
                new IdentityUserRole<string>() {  RoleId = "fab4fac1-c546-41de-aebc-a14da6895712", UserId = "b74ddd14-6340-4840-95c2-db12554843e6" }
                );
        }
    }

    //public DbSet<User> Users { get; set; }

}

